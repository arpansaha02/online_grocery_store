﻿<?php phpinfo(); ?>
