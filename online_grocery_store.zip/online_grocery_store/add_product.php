<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $price = $_POST["price"];
    $image = $_POST["image"];
    $db = new SQLite3('grocery.db');
    $stmt = $db->prepare("INSERT INTO products (name, price, image) VALUES (?, ?, ?)");
    $stmt->bindValue(1, $name, SQLITE3_TEXT);
    $stmt->bindValue(2, $price, SQLITE3_FLOAT);
    $stmt->bindValue(3, $image, SQLITE3_TEXT);
    $stmt->execute();
    header("Location: admin.html");
}
?>
