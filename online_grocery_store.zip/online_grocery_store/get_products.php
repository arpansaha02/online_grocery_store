<?php
$db = new SQLite3('grocery.db');
$results = $db->query("SELECT name, price, image FROM products");
$products = [];
while ($row = $results->fetchArray(SQLITE3_ASSOC)) {
    $products[] = $row;
}
header('Content-Type: application/json');
echo json_encode($products);
?>
