#include <stdio.h>
int main() { printf("Content-Type: text/plain\n\nOrder placed"); return 0; }