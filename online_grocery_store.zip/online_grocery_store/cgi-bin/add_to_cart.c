#include <stdio.h>
int main() { printf("Content-Type: text/plain\n\nAdded to cart"); return 0; }