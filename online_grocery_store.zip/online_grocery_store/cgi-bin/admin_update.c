#include <stdio.h>
int main() { printf("Content-Type: text/plain\n\nProduct updated"); return 0; }